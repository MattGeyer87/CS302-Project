#ifndef NODE_CPP
#define NODE_CPP

template<class PT>
struct node{
	PT info;
	node *next;
};

#endif